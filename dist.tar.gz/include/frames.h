#ifndef FRAMES_H
#define FRAMES_H

void add_frame(int id, int data);

void remove_frame();

void print_list();

int find_var(int id);

void destroy_list();

#endif