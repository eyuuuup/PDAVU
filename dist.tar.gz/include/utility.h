#ifndef UTILITY_H
#define UTILITY_H

/**
 * Prints out the constant and text blokcs on two lines.
 **/
void print_blocks();

#endif